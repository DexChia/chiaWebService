package service

import (
	"context"
	"fmt"
	"strconv"
	"strings"

	"github.com/go-redis/redis/v8"
)

// stored as hash in redis at farmerInfo:<launcher id>
type FarmerSummary struct {
	LauncherId   string
	Name         string
	JoinedAt     int64
	LastSubmitAt int64
}

// stored as list in redis at farmerPartials:<launcher id>,
// where each list item is a string of <submittedAt>:<valid>
type PartialInfo struct {
	SubmittedAt int64
	Valid       bool
}

// stored as hash in redis at farmerInfo:<launch id> and gets
// combined with the data in farmerPartials:<launcher id>
type FarmerDetail struct {
	LauncherId string
	Name       string
	JoinedAt   int64
	Partials   []PartialInfo
}

// redis partial list contains strings in the format "<submitted timestamp millis>:<true/false>"
// where true/false indicates if the partial was valid or not.
// submitted timestamp millis is milliseconds since unix epoch
func parseRedisPartialString(partialString string) PartialInfo {
	parts := strings.Split(partialString, ":")
	submittedAt, err := strconv.Atoi(parts[0])
	if err != nil {
		fmt.Printf("Bad partial record: %s\n", partialString)
		submittedAt = 0
	}

	valid, err := strconv.ParseBool(parts[1])
	if err != nil {
		fmt.Printf("Bad partial record: %s\n", partialString)
		valid = false
	}

	return PartialInfo{
		SubmittedAt: int64(submittedAt),
		Valid:       valid,
	}
}

// TODO paginate this
func GetAllFarmers() ([]FarmerSummary, error) {
	rdb := redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "", // no password set
		DB:       0,  // use default DB
	})

	defer rdb.Close()

	ctx := context.Background()

	keys, _, err := rdb.Scan(ctx, 0, "farmerInfo:*", 100).Result()

	if err != nil {
		return []FarmerSummary{}, err
	}

	result := make([]FarmerSummary, 0, len(keys))
	for _, k := range keys {
		f, err := rdb.HGetAll(ctx, k).Result()
		if err != nil {
			fmt.Printf("Error getting key %s: %+v\n", k, err)
			continue
		}

		id := f["launcherId"]
		joinedAt, err := strconv.ParseInt(f["joinedAt"], 10, 64)
		if err != nil {
			fmt.Printf("joinedAt was not an int. value: %s, err: %+v\n", f["joinedAt"], err)
			continue
		}

		var lastSubmitAt int64

		lastPartialResponse := rdb.LRange(ctx, "farmerPartials:"+id, -1, -1)
		if lastPartialResponse.Err() != nil {
			lastSubmitAt = 0
		} else {
			partials, err := lastPartialResponse.Result()
			if err != nil || len(partials) == 0 {
				lastSubmitAt = 0
			} else {
				lastPartialValue, err := lastPartialResponse.Result()
				if err != nil {
					lastSubmitAt = 0
				} else {
					partialInfo := parseRedisPartialString(lastPartialValue[0])
					lastSubmitAt = partialInfo.SubmittedAt
				}
			}

			result = append(result, FarmerSummary{LauncherId: id, Name: f["name"], JoinedAt: int64(joinedAt), LastSubmitAt: int64(lastSubmitAt)})
		}
	}

	return result, nil
}

func getRecentFarmerPartials(farmerId string) ([]PartialInfo, error) {
	rdb := redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "", // no password set
		DB:       0,  // use default DB
	})

	defer rdb.Close()

	ctx := context.Background()

	partialsRedisResult := rdb.LRange(ctx, "farmerPartials:"+farmerId, 0, 100)
	if partialsRedisResult.Err() != nil {
		return []PartialInfo{}, partialsRedisResult.Err()
	}

	partials, err := partialsRedisResult.Result()
	if err != nil {
		return []PartialInfo{}, err
	}

	result := make([]PartialInfo, 0, 100)
	for _, p := range partials {
		partialInfo := parseRedisPartialString(p)

		result = append(result, partialInfo)
	}

	return result, err
}

func GetFarmerById(farmerId string) (FarmerDetail, error) {
	rdb := redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "", // no password set
		DB:       0,  // use default DB
	})

	defer rdb.Close()

	ctx := context.Background()

	farmerRedisResult := rdb.HGetAll(ctx, "farmerInfo:"+farmerId)
	if farmerRedisResult.Err() != nil {
		return FarmerDetail{}, farmerRedisResult.Err()
	}

	farmerDataMap, err := farmerRedisResult.Result()
	if err != nil {
		return FarmerDetail{}, err
	}

	joinedAt, err := strconv.Atoi(farmerDataMap["joinedAt"])
	if err != nil {
		return FarmerDetail{}, err
	}

	partials, err := getRecentFarmerPartials(farmerId)
	if err != nil {
		return FarmerDetail{}, err
	}

	return FarmerDetail{
		LauncherId: farmerDataMap["launcherId"],
		Name:       farmerDataMap["name"],
		JoinedAt:   int64(joinedAt),
		Partials:   partials,
	}, nil
}

func UpdateFarmer(farmerId string, newName string) error {
	rdb := redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "", // no password set
		DB:       0,  // use default DB
	})

	defer rdb.Close()

	ctx := context.Background()

	rdb.HSet(ctx, "farmerInfo:"+farmerId, "name", newName)
	return nil
}
