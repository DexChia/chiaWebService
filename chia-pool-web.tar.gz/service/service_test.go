package service

import (
	"context"
	"fmt"
	"testing"

	"github.com/go-redis/redis/v8"
)

func assertEqual(t *testing.T, a interface{}, b interface{}) {
	if a != b {
		t.Fatalf("%s != %s", a, b)
	}
}

func addFarmer(id string, name string) {
	rdb := redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "", // no password set
		DB:       0,  // use default DB
	})

	ctx := context.Background()

	defer rdb.Close()

	// farmer with no partials yet
	rdb.HSet(ctx, "farmerInfo:"+id, "launcherId", id, "joinedAt", 1615699890000, "name", name)
}

func addPartials(farmerId string) {
	rdb := redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "", // no password set
		DB:       0,  // use default DB
	})

	ctx := context.Background()

	defer rdb.Close()

	rdb.RPush(ctx, fmt.Sprintf("farmerPartials:%s", farmerId), "1615699820000:false", "1615699830000:false", "1615699840000:true")
}

func deleteKeys(ctx context.Context, t *testing.T, rdb redis.Client, keyPattern string) {
	keysResponse := rdb.Keys(ctx, keyPattern)
	keys, err := keysResponse.Result()
	if err != nil {
		t.Fatal(err)
	}

	for _, key := range keys {
		rdb.Del(ctx, key)
	}
}

func cleanUpData(t *testing.T) {
	rdb := redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "", // no password set
		DB:       0,  // use default DB
	})

	defer rdb.Close()

	ctx := context.Background()

	deleteKeys(ctx, t, *rdb, "farmerInfo:*")
	deleteKeys(ctx, t, *rdb, "farmerPartials:*")
}

func TestGetAllFarmers(t *testing.T) {
	cleanUpData(t)

	allFarmers, err := GetAllFarmers()

	if err != nil {
		t.Fatalf("Didn't expect an error here: %+v", err.Error())
	}

	if len(allFarmers) != 0 {
		t.Fatal("There should be no farmers yet")
	}

	addFarmer("1000", "farmer1")
	addFarmer("2000", "farmer2")
	addPartials("2000")

	allFarmers, err = GetAllFarmers()
	assertEqual(t, 2, len(allFarmers))

	for _, farmer := range allFarmers {
		if farmer.LauncherId == "1000" {
			assertEqual(t, "farmer1", farmer.Name)
			assertEqual(t, "1000", farmer.LauncherId)
			assertEqual(t, int64(1615699890000), farmer.JoinedAt)
			assertEqual(t, int64(0), farmer.LastSubmitAt)
		}

		if farmer.LauncherId == "2000" {
			assertEqual(t, "farmer2", farmer.Name)
			assertEqual(t, "2000", farmer.LauncherId)
			assertEqual(t, int64(1615699890000), farmer.JoinedAt)
			assertEqual(t, int64(1615699840000), farmer.LastSubmitAt)
		}
	}
}

func TestGetFarmerById(t *testing.T) {
	cleanUpData(t)

	addFarmer("1000", "farmer1")
	addPartials("1000")

	farmer, err := GetFarmerById("1000")
	if err != nil {
		t.Fatalf("Unexpected error %+v", err.Error())
	}

	assertEqual(t, "1000", farmer.LauncherId)
	assertEqual(t, 3, len(farmer.Partials))

	// partials are a list so we can expect the order
	partial := farmer.Partials[0]
	assertEqual(t, int64(1615699820000), partial.SubmittedAt)
	assertEqual(t, false, partial.Valid)

	partial = farmer.Partials[1]
	assertEqual(t, int64(1615699830000), partial.SubmittedAt)
	assertEqual(t, false, partial.Valid)

	partial = farmer.Partials[2]
	assertEqual(t, int64(1615699840000), partial.SubmittedAt)
	assertEqual(t, true, partial.Valid)
}

func TestGetFarmerById_NoPartials(t *testing.T) {
	cleanUpData(t)

	addFarmer("1000", "farmer1")

	farmer, err := GetFarmerById("1000")
	if err != nil {
		t.Fatalf("Unexpected error %+v", err.Error())
	}

	assertEqual(t, "1000", farmer.LauncherId)
	assertEqual(t, 0, len(farmer.Partials))
}
